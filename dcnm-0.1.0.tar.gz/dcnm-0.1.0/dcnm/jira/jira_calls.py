#!/usr/bin/env python
"""
Jeff Kala
Tue Feb 19 8:59:03 AM 2019

collection of JIRA boilerplate calls

    Example:
        1) import core.jira_calls

            ticket = core.jira_calls.jira_create_ticket(connection_obj)

        2) from core.jira_calls import jira_create_ticket

            ticket = jira_create_ticket(connection_obj)


    Todo:
        * todo
"""
import json
from getpass import getpass
from .jira_session import JiraManager
from ..core.utilities import time_me

def jira_get_connection():
    """Connection handler to handle intial connection to JIRA and
       creating connection_obj

       +Checks minimun python version 3.6.x to support f-string formatting.
       SystemExit uses % format incase this file is ran in a system with no f-string support.

       Args (none)

       Returns:
        connection_obj (object)
    """
    import sys

    _PY3_MIN = sys.version_info[:2] >= (3, 6)
    if not _PY3_MIN:
        raise SystemExit(
            'ERROR: DCNM API package requires a minimum of Python3 version 3.6. Current version: %s'
            % ''.join(sys.version.splitlines()))
    print('\nEnter regular "first.last" credentials for JIRA ticketing\n')
    user = input('Username: ')
    password = getpass()
    base_url = 'https://jira.schwab.com/rest'
    base_url = base_url.strip()
    sess = JiraManager(base_url, user, password)
    return sess

def jira_create_ticket(connection_obj, summary, priority, description, label, component):
    """create_ticket ('story') in jira in an automated fashion.  This should be used
       in the future to help streamline builds or automations.

       Args:
        connection_obj (object) used for session managment to use API

       Returns:
        successful or failed
    """
    priority_dict = {
        "Highest": "1",
        "High": "2",
        "Medium": "3",
        "Low": "4",
        "Lowest": "5"
        }
    ct_url = '/api/2/issue/'
    data = {
        "fields":{"project":{"key":"ENS"},\
        "summary":f"{summary}",\
        "priority":{"id":priority_dict[f"{priority}"]},\
        "description":f"{description}",\
        "issuetype":{"id":"10001"},\
        "labels":[f"{label}"],\
        "components":[{"name":f"{component}"}]}
        }
    resp = connection_obj.post(ct_url, data=json.dumps(data))
    if resp.ok:
        return f'Successfully Created Ticket {resp.json()["key"]}'
    else:
        return f'Failed to Create Ticket {resp.status_code}'

def jira_create_subtask(connection_obj, parent_key, summary, description, label, component):
    """create_subtask in jira in an automated fashion.  This should be used
       in the future to help streamline builds or automations.

       Args:
        connection_obj (object) used for session managment to use API

       Returns:
        successful or failed
    """    
    ct_url = '/api/2/issue/'
    data = {
        "fields":{"project":{"key":"ENS"},\
        "parent":{"key":f"{parent_key}"},\
        "summary":f"{summary}",\
        "description":f"{description}",\
        "issuetype":{"id":"5"},\
        "labels":[f"{label}"],\
        "components":[{"name":f"{component}"}]}
        }
    resp = connection_obj.post(ct_url, data=json.dumps(data))
    if resp.ok:
        return resp.json()["key"]
    else:
        return f'Failed to Create Ticket {resp.status_code}'

def jira_update_ticket(connection_obj, ticket_name, desired_state, assignee, comment):
    """update_ticket ('story') in jira in an automated fashion.  This should be used
       in the future to help streamline builds or automations.

       Args:
        connection_obj (object) used for session managment to use API

       Returns:
        successful or failed
    """        
    transition_dict = {
        "To Do": "11",
        "In Progress": "21",
        "Done": "31"
        }
    transition_url = f'/api/2/issue/{ticket_name}/transitions?expand=transitions.fields'
    update_url = f'/api/2/issue/{ticket_name}'
    trans_data = {"transition": {"id":transition_dict[f"{desired_state}"]}}
    transition = connection_obj.post(transition_url, data=json.dumps(trans_data))
    if transition.ok:
        data = {"update": {"comment": [{"add": {"body": f"{comment}"}}]},"fields": {"assignee": {"name": f"{assignee}"}}}
        resp = connection_obj.put(update_url, data=json.dumps(data))
        if resp.ok:
            return 'Successfully Updated Ticket'
        else:
            return 'Updating ticket failed' 
    else:
        return 'Transitioning ticket state failed'
